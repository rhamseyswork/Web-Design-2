Read Me:
<!--
      CIS123-40386 (ONL) Web Page Design 2
      New Perspectives on HTML5 and CSS3, 8th Edition
      Tutorial 7
      Coding Challenge 2
      Week 15
      Assignment 5
   
      Author: Rhamseys Garcia
      Date:   4/24/2023
   -->
Read Me:
<!--
   CIS123-40386 (ONL) Web Page Design 2
   New Perspectives on HTML5 and CSS3, 8th Edition
   Tutorial 7
   Coding Challenge 3
   Week 15
   Assignment 5
   
   Author: Rhamseys Garcia
   Date:   4/24/2023   
   Filename: code7-3.html

   regular expression pattern for credit card numbers:

   ^(?:4[0-9]{12}(?:[0-9]{3})?|[25][1-7][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$

   regular expression pattern for CSC numbers:

   ^\d{3}$
   -->